package commandexecutor;

import java.util.List;

public class DependCommand extends Command{
	public DependCommand(String sentence, String [] body){
		super.sentence = sentence;
		super.body = body;
	}

	public void process(List <String> listaProgramas, List <Dependency> dependencyList){
		StringBuffer buffer = new StringBuffer(sentence);
		for(String s: body){
			buffer.append(" ");
			buffer.append(s);
		}

		System.out.println(buffer.toString());

		Dependency d;
		String programMandatory;
		String programDepending;

		boolean alreadyExists;

		int bodyLength = body.length;
		for(int i = bodyLength - 1; i > 0; i--){
			programMandatory = body[i];
			programDepending = body[i - 1];
			d = new Dependency(programMandatory, programDepending);
			alreadyExists = false;

			existingCycle: for(Dependency din: dependencyList){
				if(din.getProgramMandatory().equals(d.getProgramMandatory())){
					if(din.getProgramDepending().equals(d.getProgramDepending())){
						alreadyExists = true;
						break existingCycle;
					}
				}
			}

			if(!alreadyExists)
				dependencyList.add(d);
		}

		//System.out.println("dependency list size: " + dependencyList.size());
		//for(Dependency dtest: dependencyList){
		//	System.out.println("Mandatory: " + dtest.getProgramMandatory() + ", Depending " + dtest.getProgramDepending());
		//}
	}
}