package commandexecutor;

import java.util.ArrayList;
import java.util.List;
import exceptions.CommandValidatorException;

public class CommandValidator{
	public static Command validateCommand(String line) throws CommandValidatorException{
		if(line.length() > 80)
			throw new CommandValidatorException("line " + line + " has more than 80 characters");

		String lineTrimed = line.trim();

		int stringLength = lineTrimed.length();
		int start = 0;
		int end = 0;
		String sTemp;
		List <String> wordsList = new ArrayList();
		boolean openedWord = true;

		for(int i = 0; i < stringLength; i++){
			if(lineTrimed.charAt(i) == 32){
				if(openedWord){
					sTemp = lineTrimed.substring(start, end);
					start = i + 1;
					end = i + 1;
					wordsList.add(sTemp);
					openedWord = false;
				}
				else{
					start++;
					end++;
				}
			}
			else{
				end++;
				openedWord = true;
			}

			if(i == (stringLength - 1)){
				if(openedWord){
					sTemp = lineTrimed.substring(start, end);
					start = i + 1;
					end = i + 1;
					wordsList.add(sTemp);
				}
			}
		}

		if(wordsList.size() > 0)
		{
			if(wordsList.get(0).equals("LIST"))
				return new ListCommand("LIST", new String[0]);
			else if(wordsList.get(0).equals("INSTALL")){
				if(wordsList.size() == 2){
					String [] array = new String[1];
					array[0] = wordsList.get(1);
					return new InstallCommand("INSTALL", array);
				}
			}
			else if(wordsList.get(0).equals("REMOVE")){
				if(wordsList.size() == 2){
					String [] array = new String[1];
					array[0] = wordsList.get(1);
					return new RemoveCommand("REMOVE", array);
				}
			}
			else if(wordsList.get(0).equals("DEPEND")){
				/*System.out.println("line " + lineTrimed);
				System.out.println(wordsList.size());
				for(String s: wordsList){
					System.out.print(s + " ");
				}
				System.out.println("");*/

				String [] array = new String[wordsList.size() - 1];
				for(int i = 0; i < array.length; i++)
					array[i] = wordsList.get(i + 1);

				return new DependCommand("DEPEND", array);
			}
			else if(wordsList.get(0).equals("END")){
				return new EndCommand("END", new String[0]);
			}
			else
				throw new CommandValidatorException("command \"" + wordsList.get(0) + "\" not recognized");
		}
		else
			throw new CommandValidatorException("command not recognized");

		return new ListCommand("LIST", new String[0]);
	}
}