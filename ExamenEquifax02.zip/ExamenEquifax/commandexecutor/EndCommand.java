package commandexecutor;

import java.util.List;

public class EndCommand extends Command{
	public EndCommand(String sentence, String [] body){
		super.sentence = sentence;
		super.body = body;
	}

	public void process(List <String> listaProgramas, List <Dependency> dependencyList){
		StringBuffer buffer = new StringBuffer(sentence);
		System.out.println(buffer.toString());
	}
}