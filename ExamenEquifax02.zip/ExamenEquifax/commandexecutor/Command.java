package commandexecutor;

import java.util.List;

abstract public class Command{
	String sentence;
	String [] body;

	abstract public void process(List <String> listaProgramas, List <Dependency> dependencyList);
}