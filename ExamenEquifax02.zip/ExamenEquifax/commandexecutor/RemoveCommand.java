package commandexecutor;

import java.util.ArrayList;
import java.util.List;

public class RemoveCommand extends Command{
	public RemoveCommand(String sentence, String [] body){
		super.sentence = sentence;
		super.body = body;
	}

	public void process(List <String> listaProgramas, List <Dependency> dependencyList){
		StringBuffer buffer = new StringBuffer(sentence);
		for(String s: body){
			buffer.append(" ");
			buffer.append(s);
		}

		System.out.println(buffer.toString());

		if(!listaProgramas.contains(body[0])){
			System.out.println("\tProgram " + body[0] + " not installed");
		}
		else{
			for(Dependency d: dependencyList){
				if(d.getProgramMandatory().equals(body[0])){
					System.out.println("\tProgram " + body[0] + " still needed");
					return;
				}
			}

			listaProgramas.remove(body[0]);
			System.out.println("\tRemoving " + body[0]);

			removeMandatoriesUnnecessary(body[0], listaProgramas, dependencyList);
		}
	}

	private void removeMandatoriesUnnecessary(String program, List <String> listaProgramas, List <Dependency> dependencyList){
		List <String> myMandatories = new ArrayList();

		for(Dependency d: dependencyList){
			if(d.getProgramDepending().equals(program))
				myMandatories.add(d.getProgramMandatory());
		}

		int numDependencies;

		for(String s: myMandatories){
			numDependencies = 0;

			for(Dependency d: dependencyList){
				if(d.getProgramMandatory().equals(s)){
					if(listaProgramas.contains(d.getProgramDepending()))
						numDependencies++;
				}
			}

			if(numDependencies == 0){
				listaProgramas.remove(s);
				System.out.println("\tRemoving " + s);

				removeMandatoriesUnnecessary(s, listaProgramas, dependencyList);
			}
			else
				return;
		}
	}
}