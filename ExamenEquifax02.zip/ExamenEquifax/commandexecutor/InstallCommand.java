package commandexecutor;

import java.util.ArrayList;
import java.util.List;

public class InstallCommand extends Command{
	public InstallCommand(String sentence, String [] body){
		super.sentence = sentence;
		super.body = body;
	}

	public void process(List <String> listaProgramas, List <Dependency> dependencyList){
		StringBuffer buffer = new StringBuffer(sentence);
		for(String s: body){
			buffer.append(" ");
			buffer.append(s);
		}

		System.out.println(buffer.toString());

		if(listaProgramas.contains(body[0])){
			System.out.println("\tProgram " + body[0] + " already installed");
		}
		else{
			installWithMandatory(body[0], listaProgramas, dependencyList);
		}
	}

	private void installWithMandatory(String program, List <String> listaProgramas, List <Dependency> dependencyList){
		if(listaProgramas.contains(program))
			return;

		for(Dependency d: dependencyList){
			if(d.getProgramDepending().equals(program)){
				if(!listaProgramas.contains(d.getProgramMandatory()))
					installWithMandatory(d.getProgramMandatory(), listaProgramas, dependencyList);
			}
		}

		listaProgramas.add(program);
		System.out.println("\tInstalling " + program);
	}
}