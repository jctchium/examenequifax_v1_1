package exceptions;

public class MyExecException extends Exception{
	String message;

	public MyExecException(String message){
		this.message = message;
	}

	public String getMessage(){
			return this.message;
	}
}
