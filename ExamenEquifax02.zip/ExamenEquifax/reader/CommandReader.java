package reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import commandexecutor.Command;
import commandexecutor.CommandValidator;
import exceptions.CommandValidatorException;
import exceptions.MyExecException;

public class CommandReader{

	public static List<Command> readCommands() throws MyExecException{
		List <Command> res = new ArrayList();

		String propsPath = "config.cfg";
		Properties p = new Properties();
		try{
			p.load(new FileReader(propsPath));
		}
		catch(IOException e){
			throw new MyExecException(e.getMessage());
		}

		String filePath = p.getProperty("commandfile");

		File f = new File(filePath);
		FileReader fr;
		BufferedReader br;
		String line;
		Command c;

		try{
			fr = new FileReader(f);
			br = new BufferedReader(fr);
			while((line = br.readLine()) != null){
				try{
					c = CommandValidator.validateCommand(line);
				}
				catch(CommandValidatorException e){
					throw new MyExecException(e.getMessage());
				}
				res.add(c);
			}
		}
		catch(IOException e){
			throw new MyExecException(e.getMessage());
		}

		return res;
	}
}